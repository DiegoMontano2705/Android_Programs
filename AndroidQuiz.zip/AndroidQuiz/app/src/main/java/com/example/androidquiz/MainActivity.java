// Diego Fernando Montaño Pérez A01282875
package com.example.androidquiz;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    private static final String TAG = "StateChanged";
    private Button mTrueButton;
    private Button mFalseButton;
    private Button mNextButton;
    private TextView textView;
    private int iIDCounter = 0;
    private String toastMsg;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i(TAG,"onCreate");

        mTrueButton = findViewById(R.id.buttonTrue);
        mFalseButton = findViewById(R.id.buttonFalse);
        mNextButton = findViewById(R.id.buttonNext);
        textView = findViewById(R.id.textView);

        mTrueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(questionAnswer(getiIDCounter(),true)){
                    toastMsg = "CORRECT!";
                } else{
                    toastMsg = "INCORRECT";
                }
                Toast.makeText(MainActivity.this,toastMsg,Toast.LENGTH_SHORT).show();
            }
        });

        mFalseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(questionAnswer(getiIDCounter(),false)){
                    toastMsg = "CORRECT!";
                } else{
                    toastMsg = "INCORRECT";
                }
                Toast.makeText(MainActivity.this,toastMsg,Toast.LENGTH_SHORT).show();
            }
        });

        mNextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Checar si Id aun tiene pregunta y cambio de id cuando se da click en boton next
                if(getiIDCounter() +1 < 5) {
                    setiIDCounter(getiIDCounter() +1);
                } else {
                    setiIDCounter(0);
                }
                //Cambio de pregunta
                if(getiIDCounter() == 0) {
                    textView.setText("Is AMLO the president of Mexico?");
                }
                 else if(getiIDCounter() == 1) {
                    textView.setText("Is China the largest country in the world?");
                } else if(getiIDCounter() == 2) {
                    textView.setText("Texas is in Europe?");
                }
                if(getiIDCounter() == 3) {
                    textView.setText("Eating pizza is healthy?");
                }
                if(getiIDCounter() == 4) {
                    textView.setText("Bill Gates is the owner of Microsoft?");
                }

                Log.i(TAG, Integer.toString(getiIDCounter()));

            }
        });

    }

    public int getiIDCounter() {
        return iIDCounter;
    }

    public void setiIDCounter(int iIDCounter) {
        this.iIDCounter = iIDCounter;
    }

    public boolean questionAnswer(int id, boolean answer){
        //Amlo questiom
        if(id == 0){
            if(answer){
                return true;
            } else {
                return false;
            }
        }
        //China question
        if(id == 1){
            if(answer){
                return false;
            } else {
                return true;
            }
        }
        //Texas question
        if(id == 2){
            if(answer){
                return false;
            } else {
                return true;
            }
        }
        //Pizza question
        if(id == 3){
            if(answer){
                return false;
            } else {
                return true;
            }
        }
        //Bill Gates question
        if(id == 4){
            if(answer){
                return true;
            } else {
                return false;
            }
        }

        return false;

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i(TAG,"onStart");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i(TAG,"onPause");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.i(TAG,"onResume");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i(TAG,"onRestart");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i(TAG,"onDestroy");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG,"onStop");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.i(TAG,"onSaveInstanceState");
        textView = findViewById(R.id.textView);
        CharSequence questionText = textView.getText();
        outState.putCharSequence("savedText",questionText);
        int iSavedId = getiIDCounter();
        outState.putInt("savedId",iSavedId);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        Log.i(TAG, "onRestoreInstanceState");
        textView = findViewById(R.id.textView);
        CharSequence questionText = savedInstanceState.getCharSequence("savedText");
        textView.setText(questionText);
        int iSavedId = savedInstanceState.getInt("savedId");
        setiIDCounter(iSavedId);
    }

}
